package com.miguel.shopapp.viewmodel

import androidx.lifecycle.ViewModel

class CartViewModel: ViewModel() {
    // TODO: observar carrito y calcular total
}
