package com.miguel.shopapp.viewmodel

import androidx.lifecycle.ViewModel

class ProductViewModel: ViewModel() {
    // TODO: exponer Flow<List<Product>>, create/update/delete
}
