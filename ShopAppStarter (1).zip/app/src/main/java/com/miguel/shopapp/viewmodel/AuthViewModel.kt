package com.miguel.shopapp.viewmodel

import androidx.lifecycle.ViewModel

class AuthViewModel: ViewModel() {
    // TODO: conectar con AuthRepository
}
